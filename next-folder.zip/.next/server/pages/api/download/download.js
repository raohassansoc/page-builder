"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/download/download";
exports.ids = ["pages/api/download/download"];
exports.modules = {

/***/ "archiver":
/*!***************************!*\
  !*** external "archiver" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("archiver");

/***/ }),

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fdownload%2Fdownload&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cdownload%5Cdownload.js&middlewareConfigBase64=e30%3D!":
/*!********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fdownload%2Fdownload&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cdownload%5Cdownload.js&middlewareConfigBase64=e30%3D! ***!
  \********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _pages_api_download_download_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages\\api\\download\\download.js */ \"(api)/./pages/api/download/download.js\");\n// @ts-ignore this need to be imported from next/dist to be external\n\n\n\nconst PagesAPIRouteModule = next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule;\n// Import the userland code.\n// @ts-expect-error - replaced by webpack/turbopack loader\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_download_download_js__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_download_download_js__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/download/download\",\n        pathname: \"/api/download/download\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _pages_api_download_download_js__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRmRvd25sb2FkJTJGZG93bmxvYWQmcHJlZmVycmVkUmVnaW9uPSZhYnNvbHV0ZVBhZ2VQYXRoPS4lMkZwYWdlcyU1Q2FwaSU1Q2Rvd25sb2FkJTVDZG93bmxvYWQuanMmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7QUFDMEY7QUFDM0I7QUFDTDtBQUMxRCw0QkFBNEIsZ0hBQTBCO0FBQ3REO0FBQ0E7QUFDZ0U7QUFDaEU7QUFDQSxpRUFBZSx3RUFBSyxDQUFDLDREQUFRLFlBQVksRUFBQztBQUMxQztBQUNPLGVBQWUsd0VBQUssQ0FBQyw0REFBUTtBQUNwQztBQUNPO0FBQ1A7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWTtBQUNaLENBQUM7O0FBRUQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvP2MzNmMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHRzLWlnbm9yZSB0aGlzIG5lZWQgdG8gYmUgaW1wb3J0ZWQgZnJvbSBuZXh0L2Rpc3QgdG8gYmUgZXh0ZXJuYWxcbmltcG9ydCAqIGFzIG1vZHVsZSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9wYWdlcy1hcGkvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgaG9pc3QgfSBmcm9tIFwibmV4dC9kaXN0L2J1aWxkL3RlbXBsYXRlcy9oZWxwZXJzXCI7XG5jb25zdCBQYWdlc0FQSVJvdXRlTW9kdWxlID0gbW9kdWxlLlBhZ2VzQVBJUm91dGVNb2R1bGU7XG4vLyBJbXBvcnQgdGhlIHVzZXJsYW5kIGNvZGUuXG4vLyBAdHMtZXhwZWN0LWVycm9yIC0gcmVwbGFjZWQgYnkgd2VicGFjay90dXJib3BhY2sgbG9hZGVyXG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiLi9wYWdlc1xcXFxhcGlcXFxcZG93bmxvYWRcXFxcZG93bmxvYWQuanNcIjtcbi8vIFJlLWV4cG9ydCB0aGUgaGFuZGxlciAoc2hvdWxkIGJlIHRoZSBkZWZhdWx0IGV4cG9ydCkuXG5leHBvcnQgZGVmYXVsdCBob2lzdCh1c2VybGFuZCwgXCJkZWZhdWx0XCIpO1xuLy8gUmUtZXhwb3J0IGNvbmZpZy5cbmV4cG9ydCBjb25zdCBjb25maWcgPSBob2lzdCh1c2VybGFuZCwgXCJjb25maWdcIik7XG4vLyBDcmVhdGUgYW5kIGV4cG9ydCB0aGUgcm91dGUgbW9kdWxlIHRoYXQgd2lsbCBiZSBjb25zdW1lZC5cbmV4cG9ydCBjb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBQYWdlc0FQSVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5QQUdFU19BUEksXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9kb3dubG9hZC9kb3dubG9hZFwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2Rvd25sb2FkL2Rvd25sb2FkXCIsXG4gICAgICAgIC8vIFRoZSBmb2xsb3dpbmcgYXJlbid0IHVzZWQgaW4gcHJvZHVjdGlvbi5cbiAgICAgICAgYnVuZGxlUGF0aDogXCJcIixcbiAgICAgICAgZmlsZW5hbWU6IFwiXCJcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMtYXBpLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fdownload%2Fdownload&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cdownload%5Cdownload.js&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./pages/api/download/download.js":
/*!****************************************!*\
  !*** ./pages/api/download/download.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! fs */ \"fs\");\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var archiver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! archiver */ \"archiver\");\n/* harmony import */ var archiver__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(archiver__WEBPACK_IMPORTED_MODULE_1__);\n\n\nasync function handler(req, res) {\n    try {\n        const output = fs__WEBPACK_IMPORTED_MODULE_0___default().createWriteStream(\"next-folder.zip\");\n        const archive = archiver__WEBPACK_IMPORTED_MODULE_1___default()(\"zip\", {\n            zlib: {\n                level: 9\n            }\n        });\n        archive.on(\"error\", (err)=>{\n            throw err;\n        });\n        archive.pipe(output);\n        // Add the .next folder to the archive\n        archive.directory(\".next\", \".next\");\n        archive.finalize();\n        output.on(\"close\", ()=>{\n            res.setHeader(\"Content-Disposition\", \"attachment; filename=next-folder.zip\");\n            res.setHeader(\"Content-Type\", \"application/zip\");\n            res.setHeader(\"Content-Length\", archive.pointer());\n            fs__WEBPACK_IMPORTED_MODULE_0___default().createReadStream(\"next-folder.zip\").pipe(res);\n        });\n    } catch (error) {\n        console.error(error);\n        res.status(500).end(\"Internal Server Error\");\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZG93bmxvYWQvZG93bmxvYWQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBb0I7QUFDWTtBQUVqQixlQUFlRSxRQUFRQyxHQUFHLEVBQUVDLEdBQUc7SUFDNUMsSUFBSTtRQUNGLE1BQU1DLFNBQVNMLDJEQUFvQixDQUFDO1FBQ3BDLE1BQU1PLFVBQVVOLCtDQUFRQSxDQUFDLE9BQU87WUFDOUJPLE1BQU07Z0JBQUVDLE9BQU87WUFBRTtRQUNuQjtRQUVBRixRQUFRRyxFQUFFLENBQUMsU0FBUyxDQUFDQztZQUNuQixNQUFNQTtRQUNSO1FBRUFKLFFBQVFLLElBQUksQ0FBQ1A7UUFFYixzQ0FBc0M7UUFDdENFLFFBQVFNLFNBQVMsQ0FBQyxTQUFTO1FBRTNCTixRQUFRTyxRQUFRO1FBRWhCVCxPQUFPSyxFQUFFLENBQUMsU0FBUztZQUNqQk4sSUFBSVcsU0FBUyxDQUFDLHVCQUF1QjtZQUNyQ1gsSUFBSVcsU0FBUyxDQUFDLGdCQUFnQjtZQUM5QlgsSUFBSVcsU0FBUyxDQUFDLGtCQUFrQlIsUUFBUVMsT0FBTztZQUMvQ2hCLDBEQUFtQixDQUFDLG1CQUFtQlksSUFBSSxDQUFDUjtRQUM5QztJQUNGLEVBQUUsT0FBT2MsT0FBTztRQUNkQyxRQUFRRCxLQUFLLENBQUNBO1FBQ2RkLElBQUlnQixNQUFNLENBQUMsS0FBS0MsR0FBRyxDQUFDO0lBQ3RCO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9wYWdlcy9hcGkvZG93bmxvYWQvZG93bmxvYWQuanM/YzY0MSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihyZXEsIHJlcykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBvdXRwdXQgPSBmcy5jcmVhdGVXcml0ZVN0cmVhbSgnbmV4dC1mb2xkZXIuemlwJyk7XHJcbiAgICBjb25zdCBhcmNoaXZlID0gYXJjaGl2ZXIoJ3ppcCcsIHtcclxuICAgICAgemxpYjogeyBsZXZlbDogOSB9LCAvLyBTZXQgdGhlIGNvbXByZXNzaW9uIGxldmVsIChvcHRpb25hbClcclxuICAgIH0pO1xyXG5cclxuICAgIGFyY2hpdmUub24oJ2Vycm9yJywgKGVycikgPT4ge1xyXG4gICAgICB0aHJvdyBlcnI7XHJcbiAgICB9KTtcclxuXHJcbiAgICBhcmNoaXZlLnBpcGUob3V0cHV0KTtcclxuXHJcbiAgICAvLyBBZGQgdGhlIC5uZXh0IGZvbGRlciB0byB0aGUgYXJjaGl2ZVxyXG4gICAgYXJjaGl2ZS5kaXJlY3RvcnkoJy5uZXh0JywgJy5uZXh0Jyk7XHJcblxyXG4gICAgYXJjaGl2ZS5maW5hbGl6ZSgpO1xyXG5cclxuICAgIG91dHB1dC5vbignY2xvc2UnLCAoKSA9PiB7XHJcbiAgICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtRGlzcG9zaXRpb24nLCAnYXR0YWNobWVudDsgZmlsZW5hbWU9bmV4dC1mb2xkZXIuemlwJyk7XHJcbiAgICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi96aXAnKTtcclxuICAgICAgcmVzLnNldEhlYWRlcignQ29udGVudC1MZW5ndGgnLCBhcmNoaXZlLnBvaW50ZXIoKSk7XHJcbiAgICAgIGZzLmNyZWF0ZVJlYWRTdHJlYW0oJ25leHQtZm9sZGVyLnppcCcpLnBpcGUocmVzKTtcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgIHJlcy5zdGF0dXMoNTAwKS5lbmQoJ0ludGVybmFsIFNlcnZlciBFcnJvcicpO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOlsiZnMiLCJhcmNoaXZlciIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJvdXRwdXQiLCJjcmVhdGVXcml0ZVN0cmVhbSIsImFyY2hpdmUiLCJ6bGliIiwibGV2ZWwiLCJvbiIsImVyciIsInBpcGUiLCJkaXJlY3RvcnkiLCJmaW5hbGl6ZSIsInNldEhlYWRlciIsInBvaW50ZXIiLCJjcmVhdGVSZWFkU3RyZWFtIiwiZXJyb3IiLCJjb25zb2xlIiwic3RhdHVzIiwiZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/download/download.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fdownload%2Fdownload&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cdownload%5Cdownload.js&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();